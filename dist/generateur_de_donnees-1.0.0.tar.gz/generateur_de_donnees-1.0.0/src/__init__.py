from generateur_numerique.controleur import Controleur
from generateur_numerique.formule_affine import FormuleAffine
from generateur_numerique.formule_bruit import FormuleBruit
from generateur_numerique.formule_mono_periode import FormuleMonoPeriode

from generateur_textuel.function import get_html_from_url, extrac_elem, create_file, trier_element